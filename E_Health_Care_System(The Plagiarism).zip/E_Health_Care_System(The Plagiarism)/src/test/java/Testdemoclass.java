import static org.junit.Assert.*;

import org.junit.Test;

import com.app.test.Client;

public class Testdemoclass {
	Client c1=new Client();
	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
