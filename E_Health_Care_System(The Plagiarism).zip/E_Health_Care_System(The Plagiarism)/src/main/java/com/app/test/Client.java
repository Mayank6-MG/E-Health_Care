package com.app.test;
import java.util.Scanner;

import com.app.dao.DoctorDao;
import com.app.dao.UserDao;
import com.app.dao.impl.SendEmail;
import com.app.factory.DoctorFactory;
import com.app.factory.UserFactory;
import com.app.model.Doctor;
import com.app.model.User;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sn=new Scanner(System.in);
		UserDao dao=UserFactory.getUser();
		DoctorDao dao1=DoctorFactory.getUser();
		System.out.println("Welcome.......!");
		boolean run = true;
		while(run) {
			System.out.println("Please Select The Options Below");
			System.out.println("Press 1 For New Registration:->");
			System.out.println("Press 2 For Getting The Details On ID:->");
			System.out.println("Press 3 For Updating Prescription:->");
			System.out.println("Press 4 To Close:->");
			int choice =sn.nextInt();
			switch (choice) {
			case 1:{
				System.out.println("Press 1 For Patient Registration!");
				System.out.println("Press 2 For Doctor Registration!");
				int n=sn.nextInt();
				if(n==1)
				{
				int i=dao.register();
				if(i==1) {
				System.out.println("Successfully Register");
				
				}else {
				System.out.println("Something went wrong...!");
				}
				}
				if(n==2)
				{
					int i=dao1.registerd();
					if(i==1) {
					System.out.println("Successfully Register");
					
					}else {
					System.out.println("Something went wrong...!");
					}
				}
				
				break;
			}
			case 2:{
				System.out.println("Whose data Do you want!");
				System.out.println("Press 1 For Patient!");
				System.out.println("Press 2 For Doctor!");
				int n=sn.nextInt();
				if(n==1)
				{
				System.out.println("Enter your id for find user:");
				int n1=sn.nextInt();
				User u1=dao.findById(n1);
				System.out.println("User Data:"+u1);
				}
				if(n==2)
				{
					System.out.println("Enter your id for find user:");
					int id=sn.nextInt();
					Doctor u2=dao1.findById1(id);
					System.out.println("User Data:"+u2);
				}
				
				break;}
			case 3:{
				
				System.out.println("Enter your id for find user:");
				int id=sn.nextInt();
				User u1=dao.findById(id);
				System.out.println("User Data:"+u1);
				SendEmail s1=new SendEmail();
				Scanner in=new Scanner(System.in);
				System.out.println("Enter The Prescription!");
				String num=in.nextLine();
				s1.data(u1.getAddress(), num);
				break;
			}
			case 4:
		     {
		    	 run = false;
		    	 System.out.println(".....Thank you!.....");
		    	 System.out.println("-----Good Day!-----");
		     }
			
	}

}
}
}
