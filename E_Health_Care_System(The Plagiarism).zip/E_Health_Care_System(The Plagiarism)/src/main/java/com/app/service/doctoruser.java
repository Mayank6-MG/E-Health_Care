package com.app.service;

import com.app.dto.DoctorInput;
import com.app.model.Doctor;

public class doctoruser {
	public Doctor registerd() {
		return DoctorInput.registerd();
		
	}
}
