package com.app.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.app.dao.UserDao;
import com.app.model.Doctor;
import com.app.model.User;
import com.app.service.UserService;
import com.app.util.HibernateUtil;

public class UserDaoImpl implements UserDao {
	
	public int register() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();
			User user = new UserService().register();
			Doctor doctor=new Doctor();
			Query<Doctor> query=session.createQuery("From Doctor");
			System.out.println("------------List Of Doctors------------------------");
			System.out.println("ID\t Name");
			for(Doctor doc:query.list()) {
				System.out.println(doc.getId()+"\t"+doc.getFirstName()+"  "+doc.getLastName());
							
			}
			System.out.println("----------------------------------------------------------");
			System.out.println("Please enter your Docto's Id:");
			int id=new Scanner(System.in).nextInt();
			query=session.createQuery("From Doctor where id="+id);
			doctor=query.uniqueResult();
			List<User>users=new ArrayList<User>();
			users.add(user);
			doctor.setUser(users);
			session.save(doctor);
			session.save(user);
			tx.commit();
			int i=user.getPid();
			System.out.println("Your Id Is " + i);
			System.out.println("Secure Your Id For Future Reference");
			
			
			
			

			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} /*
			 * finally { if (session != null) { session.close(); }
			 */
		}


	
	public User findById(int id) {
		// TODO Auto-generated method stub
		SessionFactory factory= factory=new Configuration().configure("hibernate-cfg.xml").buildSessionFactory();
		Session	session = factory.openSession();
		Transaction tx =session.beginTransaction();
		Query query=session.createQuery("From User u where u.id=:id ");
		query.setParameter("id", id);
		List<User> user=query.list();
		return user.get(0);
	}
	
}
