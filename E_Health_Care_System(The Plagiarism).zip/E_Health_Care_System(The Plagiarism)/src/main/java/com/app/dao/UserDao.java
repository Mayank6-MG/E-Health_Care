package com.app.dao;


import com.app.model.User;
public interface UserDao {
	int register();
	User findById(int id);
	
	
	
}
