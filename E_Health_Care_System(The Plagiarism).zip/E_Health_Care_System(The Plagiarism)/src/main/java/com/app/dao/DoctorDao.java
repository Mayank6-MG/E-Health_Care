package com.app.dao;
import com.app.model.Doctor;

public interface DoctorDao {
	int registerd();
	Doctor findById1(int id);
}
