package com.app.dao.impl;

import java.util.List;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.app.dao.DoctorDao;
import com.app.model.Doctor;
import com.app.model.User;
import com.app.service.doctoruser;
import com.app.util.HibernateUtil;




public class DoctorDaoImpl implements DoctorDao {
	public int registerd() {
		// TODO Auto-generated method stub
		/*Session session = null;
		Transaction tx = null;
		try {
			session = HibernateUtil.getSession();
			tx = session.beginTransaction();*/
		try {SessionFactory factory=factory=new Configuration().configure("hibernate-cfg.xml").buildSessionFactory();
		Session session=factory.openSession();
		Transaction tx=session.beginTransaction();
		session=HibernateUtil.getSession();
		tx=session.beginTransaction();
			Doctor doctor = new doctoruser().registerd();
			//System.out.println(user);
			session.save(doctor);
			int i=doctor.getId();
			System.out.println("Your Id Is " + i);
			System.out.println("Secure Your Id For Future Reference");
			tx.commit();
			/*
			 * SendEmail s1=new SendEmail(); Scanner in=new Scanner(System.in);
			 * System.out.println("Enter The Prescription!"); String num=in.nextLine();
			 * s1.data(doctor.getAddress(), num);
			 */
			
			

			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} /*finally {
			if (session != null) {
				session.close();
			}*/
		}
	public Doctor findById1(int id) {
		// TODO Auto-generated method stub
		SessionFactory factory= factory=new Configuration().configure("hibernate-cfg.xml").buildSessionFactory();
		Session	session = factory.openSession();
		Transaction tx =session.beginTransaction();
		Query query=session.createQuery("From Doctor d where d.id=:id ");
		query.setParameter("id", id);
		List<Doctor> doctor=query.list();
		return doctor.get(0);
	}
	}
	
	

	

