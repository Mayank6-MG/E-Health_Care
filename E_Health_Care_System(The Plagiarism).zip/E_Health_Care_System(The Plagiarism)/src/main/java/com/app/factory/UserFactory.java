package com.app.factory;

import com.app.dao.UserDao;

import com.app.dao.impl.UserDaoImpl;

public class UserFactory {
	public static UserDao getUser() {
		return new UserDaoImpl();
	}
	
}
