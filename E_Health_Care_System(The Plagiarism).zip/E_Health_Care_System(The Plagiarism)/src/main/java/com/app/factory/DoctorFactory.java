package com.app.factory;

import com.app.dao.DoctorDao;
import com.app.dao.impl.DoctorDaoImpl;


public class DoctorFactory {
	public static DoctorDao getUser() {
		return new DoctorDaoImpl();
	}
}
