package com.app.dto;

import java.util.Scanner;

import com.app.model.Doctor;
import com.app.model.User;

public class InputRequest {
	static  Scanner sn=new Scanner(System.in);
	 public static User register() {
		
		 System.out.println("Enter User Details:");
		 System.out.println("Enter user First name:");
		 String fname=sn.next();
		 System.out.println("Enter user Last name:");
		 String lname=sn.next();
		 System.out.println("Enter user MailID:");
		 String mailid=sn.next();
		 System.out.println("Enter user Mobile:");
		 long mob=sn.nextLong();
		 return addUser(fname, lname, mailid, mob);
		 
	 }
	 private static User addUser(String fname, String lname, String mailid, long mob) {
			User user=new User();
			 user.setAddress(mailid);
			 user.setFirstName(fname);
			 user.setLastName(lname);
			 user.setMobile(mob);
			 return user;
			 
		}
	
		
		
}

