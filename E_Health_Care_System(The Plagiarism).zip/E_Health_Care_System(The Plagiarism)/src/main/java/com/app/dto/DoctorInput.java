package com.app.dto;

import java.util.Scanner;

import com.app.model.Doctor;


public class DoctorInput {
	static  Scanner sn=new Scanner(System.in);
	 public static Doctor registerd() {
		
		 System.out.println("Enter User Details:");
		 System.out.println("Enter user First name:");
		 String fname=sn.next();
		 System.out.println("Enter user Last name:");
		 String lname=sn.next();
		 System.out.println("Enter user MailID:");
		 String mailid=sn.next();
		 System.out.println("Enter user Mobile:");
		 long mob=sn.nextLong();
		 return addDoctor(fname, lname, mailid, mob);
		 
	 }
	 private static Doctor addDoctor(String fname, String lname, String mailid, long mob) {
		// TODO Auto-generated method stub
		 Doctor doctor=new Doctor();
		 	doctor.setAddress(mailid);
		 	doctor.setFirstName(fname);
		 	doctor.setLastName(lname);
		 	doctor.setMobile(mob);
			 return doctor;
			 
		
	}
	
}